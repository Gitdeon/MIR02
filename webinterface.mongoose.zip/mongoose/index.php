#!/usr/bin/php-cgi7.0
<html><body><center><p><br><p><br>

<font face=arial size=7 color=darkblue>LIACS Search</font>
<p>
<form enctype="multipart/form-data" action="./search.process.php" method="post">
<input name="myquery" size="60">
<input name="Search" value="search" type="submit"> </form>

</center></body></html>
